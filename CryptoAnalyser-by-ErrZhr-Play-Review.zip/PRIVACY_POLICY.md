# Privacy Policy — CryptoAnalyser-by ErrZhr

**Last updated: 19 October 2026**

CryptoAnalyser-by ErrZhr provides informational cryptocurrency market data, technical indicators, historical candle analysis, and recent market headlines. It is not an exchange, wallet, broker, or order-execution service.

## Information and network requests

The app does not ask users to provide a name, email address, phone number, contacts, photos, camera, microphone, or precise location. It does not require an exchange account or API keys and does not place trades.

To provide its features, the app sends requests to Bitget public market-data endpoints and public RSS feeds from CoinDesk and Cointelegraph. These independent providers may receive technical connection information (for example, an IP address, request time, and device/network metadata) as part of serving requests. Their handling of such information is governed by their own privacy policies and terms. The app developer does not operate those services and cannot control their server logs or retention practices.

The current app version does not provide user accounts, does not intentionally store personal information on a developer-controlled server, and does not sell personal information. Market symbols entered by a user are used to request the corresponding public market data.

## Data security and retention

Network requests use HTTPS where supported by the endpoints configured in the app. The app does not request access to location, contacts, camera, microphone, or files. No developer-operated account database is used in this version.

## Children

This app is a financial-information tool and is not designed specifically for children. The developer does not knowingly collect personal information from children.

## Financial information disclaimer

All information, indicators, scores, historical ranges, and example backtests are provided for general informational and educational purposes only. They are not personalized financial, investment, tax, or legal advice, and do not guarantee future results. Cryptocurrency trading, especially futures and leverage, can cause substantial or total loss. Users are responsible for independently verifying information and making their own decisions.

## Third-party services

The app uses public endpoints provided by Bitget and RSS feeds provided by CoinDesk and Cointelegraph. These providers are independent third parties. CryptoAnalyser-by ErrZhr is not an official Bitget product and is not endorsed by these providers. Please consult each provider's current privacy policy and terms.

## Changes and contact

This policy may be updated if the app's features or data practices change. Before publishing, the developer must add a real contact email and host this policy at a stable, publicly accessible HTTPS URL, then enter that URL in Google Play Console. Do not publish this draft unchanged without filling in the developer's contact details.

**Developer contact:** [Add your real support email before publication]
